from flask import Flask, render_template, request, redirect, url_for, session
import mysql.connector
from mysql.connector import Error
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Change this to a random key for production

# MySQL configuration
db_config = {
    'host': 'localhost',
    'user': 'root',  # Your MySQL username
    'password': 'Jayambe@123',  # Your MySQL password
    'database': 'iit_indore'
}

def get_db_connection():
    connection = mysql.connector.connect(**db_config)
    return connection

@app.route('/')
def home():
    return render_template('home.htm')

@app.route('/register', methods=['GET', 'POST'])
def register():
    cursor = None  # Initialize cursor
    if request.method == 'POST':
        user_id = request.form['user_id']  # Ensure this matches your HTML input name
        mobile_number = request.form['mobile_number']  # Ensure this matches your HTML input name
        password = generate_password_hash(request.form['password'])

        try:
            connection = get_db_connection()
            cursor = connection.cursor()
            cursor.execute(
                'INSERT INTO users (user_id, mobile_number, password) VALUES (%s, %s, %s)',
                (user_id, mobile_number, password)
            )
            connection.commit()
            return redirect(url_for('home'))
        except Error as e:
            print("Error while connecting to MySQL", e)
            return 'Registration failed. Please try again.'
        finally:
            if cursor:
                cursor.close()
            if connection:
                connection.close()
    return render_template('register.htm')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user_id = request.form['user_id']
        password = request.form['password']
        
        connection = get_db_connection()
        cursor = connection.cursor()
        cursor.execute('SELECT password FROM users WHERE user_id = %s', (user_id,))
        result = cursor.fetchone()
        cursor.close()
        connection.close()
        
        if result and check_password_hash(result[0], password):
            session['user_id'] = user_id
            return redirect(url_for('welcome'))
        
        return 'Invalid UserID or Password'
    
    return render_template('login.htm')  # Render the login page for GET requests


@app.route('/welcome')
def welcome():
    if 'user_id' in session:
        return render_template('welcome.htm', user_id=session['user_id'])
    return redirect(url_for('home'))

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
