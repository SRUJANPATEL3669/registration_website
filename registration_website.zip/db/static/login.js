// College name switch between English and Hindi
const collegeName = document.getElementById('collegeName');

const names = [
  'Indian Institute of Technology Indore',
  'भारतीय प्रौद्योगिकी संस्थान इंदौर'
];

let currentIndex = 0;

function switchCollegeName() {
  currentIndex = (currentIndex + 1) % names.length;
  collegeName.textContent = names[currentIndex];
}

// Switch name every 3 seconds
setInterval(switchCollegeName, 3000);
