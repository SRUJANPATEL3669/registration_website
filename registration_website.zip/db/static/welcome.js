function openCourseList() {
    const courseWindow = window.open("", "_blank", "width=600,height=400");
    courseWindow.document.write(`
        <html>
        <head>
            <title>CSE Course List</title>
            <style>
                body {
                    font-family: 'Arial', sans-serif;
                    background-color: #f7f7f7;
                    padding: 20px;
                    color: #333;
                    text-align: center;
                }
                h2 {
                    color: #5c5cad;
                }
                ul {
                    list-style-type: none;
                    padding: 0;
                }
                li {
                    background: #f1f1f1;
                    margin: 10px 0;
                    padding: 10px;
                    border-radius: 5px;
                    box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
                }
            </style>
        </head>
        <body>
            <h2>CSE Course List</h2>
            <ul>
                <li>Discrete Mathematical Structures</li>
                <li>Data Structures and Algorithms</li>
                <li>Operating Systems</li>
                <li>Database And Information Systems</li>
                <li>Computer Networks</li>
                <li>Logic Design</li>
                <li>Automata Theory and Logic</li>
                <li>Design and Analysis of Algorithms</li>
                <li>Computer Architecture</li>
                <li>Parallel Computing</li>
                <li>Optimization Algorithms and Techniques </li>
                <li>Computer Graphics and Visualization</li>
                <li>Computer Graphics and Visualization</li>
                <li>Software Engineering</li>
                <li>Compiler Techniques</li>
                <li>UX/UI Design</li>
                <li>Matrix Factorization and Applications</li>
                <li>Mathematics for AI and ML</li>
                <li>Foundation of Algebraic Graph Theory</li>
                <li>Foundations of Hardware Security</li>
                <li>Introduction to Blockchain</li>
                <li>Introduction to Complexity Theory</li>
                <li>Introduction to Internet of Things</li>
                <li>Foundations of Cryptography</li>
                <li>Introduction to Big Data Analysis</li>
                <li>Foundations of Secure Computation</li>
                <li>Computer and Network Security</li>
                <li>Soft Computing</li>
                <li>Machine Learning</li>
            </ul>
        </body>
        </html>
    `);
}
